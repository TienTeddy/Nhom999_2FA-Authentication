﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ShopThoiTrang.Models;

namespace ShopThoiTrang.Controllers
{
    public class dbo_LoaiSPController : Controller
    {
        private DataProvider db = new DataProvider();

        // GET: dbo_LoaiSP
        public ActionResult Index()
        {
            return View(db.dbo_LoaiSP.ToList());
        }

        // GET: dbo_LoaiSP/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            dbo_LoaiSP dbo_LoaiSP = db.dbo_LoaiSP.Find(id);
            if (dbo_LoaiSP == null)
            {
                return HttpNotFound();
            }
            return View(dbo_LoaiSP);
        }

        // GET: dbo_LoaiSP/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: dbo_LoaiSP/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "mal,tenl")] dbo_LoaiSP dbo_LoaiSP)
        {
            if (ModelState.IsValid)
            {
                db.dbo_LoaiSP.Add(dbo_LoaiSP);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(dbo_LoaiSP);
        }

        // GET: dbo_LoaiSP/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            dbo_LoaiSP dbo_LoaiSP = db.dbo_LoaiSP.Find(id);
            if (dbo_LoaiSP == null)
            {
                return HttpNotFound();
            }
            return View(dbo_LoaiSP);
        }

        // POST: dbo_LoaiSP/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "mal,tenl")] dbo_LoaiSP dbo_LoaiSP)
        {
            if (ModelState.IsValid)
            {
                db.Entry(dbo_LoaiSP).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(dbo_LoaiSP);
        }

        // GET: dbo_LoaiSP/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            dbo_LoaiSP dbo_LoaiSP = db.dbo_LoaiSP.Find(id);
            if (dbo_LoaiSP == null)
            {
                return HttpNotFound();
            }
            return View(dbo_LoaiSP);
        }

        // POST: dbo_LoaiSP/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            dbo_LoaiSP dbo_LoaiSP = db.dbo_LoaiSP.Find(id);
            db.dbo_LoaiSP.Remove(dbo_LoaiSP);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
