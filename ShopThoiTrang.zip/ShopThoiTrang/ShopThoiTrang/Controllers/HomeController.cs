﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShopThoiTrang.Models;
using System.Data;
using System.Data.Entity;
using System.Net;

namespace ShopThoiTrang.Controllers
{
    public class HomeController : Controller
    {
        private DataProvider db = new DataProvider();

        // GET: dbo_SanPham
        public ActionResult Index()
        {
            var dbo_SanPham = db.dbo_SanPham.Include(d => d.dbo_LoaiSP);

            ViewBag.loaisp = db.dbo_LoaiSP.ToList();
            return View(dbo_SanPham.ToList());
        }

        public ActionResult About()
        {
            ViewBag.Message = "Home";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Home";

            return View();
        }
    }
}
