﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ShopThoiTrang.Models;

namespace ShopThoiTrang.Controllers
{
    public class dbo_SanPhamController : Controller
    {
        private DataProvider db = new DataProvider();

        // GET: dbo_SanPham
        public ActionResult Index()
        {
            var dbo_SanPham = db.dbo_SanPham.Include(d => d.dbo_LoaiSP);
            return View(dbo_SanPham.ToList());
        }

        // GET: dbo_SanPham/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            dbo_SanPham dbo_SanPham = db.dbo_SanPham.Find(id);
            if (dbo_SanPham == null)
            {
                return HttpNotFound();
            }
            return View(dbo_SanPham);
        }

        // GET: dbo_SanPham/Create
        public ActionResult Create()
        {
            ViewBag.mal = new SelectList(db.dbo_LoaiSP, "mal", "tenl");
            return View();
        }

        // POST: dbo_SanPham/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "masp,mal,tensp,giasp,trangthai,soluong,images1,images2,images3,thongtin")] dbo_SanPham dbo_SanPham)
        {
            if (ModelState.IsValid)
            {
                db.dbo_SanPham.Add(dbo_SanPham);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.mal = new SelectList(db.dbo_LoaiSP, "mal", "tenl", dbo_SanPham.mal);
            return View(dbo_SanPham);
        }

        // GET: dbo_SanPham/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            dbo_SanPham dbo_SanPham = db.dbo_SanPham.Find(id);
            if (dbo_SanPham == null)
            {
                return HttpNotFound();
            }
            ViewBag.mal = new SelectList(db.dbo_LoaiSP, "mal", "tenl", dbo_SanPham.mal);
            return View(dbo_SanPham);
        }

        // POST: dbo_SanPham/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "masp,mal,tensp,giasp,trangthai,soluong,images1,images2,images3,thongtin")] dbo_SanPham dbo_SanPham)
        {
            if (ModelState.IsValid)
            {
                db.Entry(dbo_SanPham).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.mal = new SelectList(db.dbo_LoaiSP, "mal", "tenl", dbo_SanPham.mal);
            return View(dbo_SanPham);
        }

        // GET: dbo_SanPham/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            dbo_SanPham dbo_SanPham = db.dbo_SanPham.Find(id);
            if (dbo_SanPham == null)
            {
                return HttpNotFound();
            }
            return View(dbo_SanPham);
        }

        // POST: dbo_SanPham/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            dbo_SanPham dbo_SanPham = db.dbo_SanPham.Find(id);
            db.dbo_SanPham.Remove(dbo_SanPham);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
