namespace ShopThoiTrang.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class dbo_SanPham
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public dbo_SanPham()
        {
            dbo_HoaDon = new HashSet<dbo_HoaDon>();
        }

        [Key]
        public int masp { get; set; }

        public int? mal { get; set; }

        [Required]
        [StringLength(100)]
        public string tensp { get; set; }

        public double? giasp { get; set; }

        [StringLength(5)]
        public string trangthai { get; set; }

        public int? soluong { get; set; }

        [StringLength(100)]
        public string images1 { get; set; }

        [StringLength(100)]
        public string images2 { get; set; }

        [StringLength(100)]
        public string images3 { get; set; }

        [StringLength(500)]
        public string thongtin { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<dbo_HoaDon> dbo_HoaDon { get; set; }

        public virtual dbo_LoaiSP dbo_LoaiSP { get; set; }
    }
}
