namespace ShopThoiTrang.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class dbo_ChiTietHD
    {
        [Key]
        public int mact { get; set; }

        public int? mahd { get; set; }

        public double? dongia { get; set; }

        public int? khuyenmai { get; set; }

        public DateTime? ngaydat { get; set; }

        [StringLength(9)]
        public string trangthai { get; set; }

        public int? soluong { get; set; }

        public virtual dbo_HoaDon dbo_HoaDon { get; set; }
    }
}
