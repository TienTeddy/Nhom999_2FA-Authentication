namespace ShopThoiTrang.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class DataProvider : DbContext
    {
        public DataProvider()
            : base("name=DataProvider")
        {
        }

        public virtual DbSet<dbo_ChiTietHD> dbo_ChiTietHD { get; set; }
        public virtual DbSet<dbo_HoaDon> dbo_HoaDon { get; set; }
        public virtual DbSet<dbo_LoaiSP> dbo_LoaiSP { get; set; }
        public virtual DbSet<dbo_SanPham> dbo_SanPham { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<dbo_SanPham>()
                .Property(e => e.images1)
                .IsUnicode(false);

            modelBuilder.Entity<dbo_SanPham>()
                .Property(e => e.images2)
                .IsUnicode(false);

            modelBuilder.Entity<dbo_SanPham>()
                .Property(e => e.images3)
                .IsUnicode(false);
        }
    }
}
