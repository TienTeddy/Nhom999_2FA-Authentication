namespace ShopThoiTrang.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class dbo_HoaDon
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public dbo_HoaDon()
        {
            dbo_ChiTietHD = new HashSet<dbo_ChiTietHD>();
        }

        [Key]
        public int mahd { get; set; }

        public int? masp { get; set; }

        public int? khuyenmai { get; set; }

        public int? soluong { get; set; }

        public double? tonggia { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<dbo_ChiTietHD> dbo_ChiTietHD { get; set; }

        public virtual dbo_SanPham dbo_SanPham { get; set; }
    }
}
